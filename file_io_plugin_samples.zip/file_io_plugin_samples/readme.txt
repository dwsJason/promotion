This is a sample project to show how image and animation file i/o plugins
are working based on the plugin interface description that can be found
at http://www.cosmigo.com/promotion/